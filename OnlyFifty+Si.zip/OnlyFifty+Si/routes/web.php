<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GeriatraController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/IniciarSesion', function () {
    return view('IniciarSesion');
});

Route::get('/geriatra', function () {
    return view('geriatras.indexGeriatra');
});

Route::get('geriatra/create',[GeriatraController::class,'create']);



















Route::get('/paginaInicio', function () {
    return view('paginaInicio');
});

Route::get('/FormularioCrearPaciente', function () {
    return view('FormularioCrearPaciente');
});

Route::get('/FormularioAgregarEnfermedad', function () {
    return view('FormularioAgregarEnfermedad');
});

Route::get('/FormularioAgregarTratamiento', function () {
    return view('FormularioAgregarTratamiento');
});

Route::get('/FormularioAgregarMedicamento', function () {
    return view('FormularioAgregarMedicamento');
});

Route::get('/FormularioAgendarCitasMedicas', function () {
    return view('FormularioAgendarCitasMedicas');
});
