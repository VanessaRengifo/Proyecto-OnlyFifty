  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">

<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> Only Fifty+. </a>

    <nav class="navbar">
        <a href="#home">Inicio</a>
        <a href="#services">Crear Pacientes</a>
        <a href="#about">Agregar Enfermedad</a>
        <a href="#doctors">Agregar Tratamiento</a>
        <a href="#review">Agregar Medicamentos</a>
        <a href="#blogs">Configuración</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>
<?php /**PATH C:\xampp\htdocs\OnlyFifty+Si\resources\views/barraNavegacionInicio.blade.php ENDPATH**/ ?>