create
<?php /**PATH C:\xampp\htdocs\OnlyFifty+Si\resources\views/geriatras/create.blade.php ENDPATH**/ ?>