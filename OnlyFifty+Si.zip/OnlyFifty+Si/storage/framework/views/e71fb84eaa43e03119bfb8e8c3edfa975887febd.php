<section class="doctors" id="doctors">
    <br><br><br><br><br>
    <h1 class="heading"> Nuestros <span>pacientes</span> </h1>

    <div class="box-container">
        <?php $__currentLoopData = $geriatras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geriatras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box">

            <img src="image/doc-1.jpg" alt="">
            <h3>Paciente 1</h3>
            <span><?php echo e($geriatras ->NOMBRE_GERIATRA); ?></span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>


    </div>

</section>
<?php /**PATH C:\xampp\htdocs\OnlyFifty+Si\resources\views/geriatras/vistaGeriatra.blade.php ENDPATH**/ ?>