  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">

<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> Only Fifty+. </a>

    <nav class="navbar">
        <a href="#home">Inicio</a>
        <a href="#services">Servicios</a>
        <a href="#about">Informacion</a>
        <a href="#review">review</a>
        <a href="#blogs">blogs</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<script src="js/script.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\OnlyFifty+Si\resources\views/barraNavegacion.blade.php ENDPATH**/ ?>