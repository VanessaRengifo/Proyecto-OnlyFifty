  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">

<!-- header section starts  -->

<header class="header">

    <a href="#" class="logo"> <i class="fas fa-heartbeat"></i> Only Fifty+. </a>

    <nav class="navbar">
        <a href="{{url('paginaInicio')}}">Inicio</a>
        <a href="{{url('FormularioCrearPaciente')}}">Crear Pacientes</a>
        <a href="{{url('FormularioAgendarCitasMedicas')}}">Agendar Citas Medicas</a>
        <a href="{{url('FormularioAgregarEnfermedad')}}">Agregar Enfermedad</a>
        <a href="{{url('FormularioAgregarTratamiento')}}">Agregar Tratamiento</a>
        <a href="{{url('FormularioAgregarMedicamento')}}">Agregar Medicamentos</a>
        <a href="#blogs">Configuración</a>
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<script src="js/script.js"></script>

</body>
</html>
