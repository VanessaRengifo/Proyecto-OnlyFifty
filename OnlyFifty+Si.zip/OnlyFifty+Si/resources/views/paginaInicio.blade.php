@include('barraNavegacionInicio')

<!-- doctors section starts  -->

<section class="doctors" id="doctors">
    <br><br><br><br><br>
    <h1 class="heading"> Nuestros <span>pacientes</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="image/doc-1.jpg" alt="">
            <h3>Paciente 1</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-2.jpg" alt="">
            <h3>Paciente 2</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-3.jpg" alt="">
            <h3>Paciente 3</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-4.jpg" alt="">
            <h3>Paciente 4</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-5.jpg" alt="">
            <h3>Paciente 5</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>

        <div class="box">
            <img src="image/doc-5.jpg" alt="">
            <h3>Paciente 6</h3>
            <span>Nombre del geriatra</span>
            <div class="share">
                <a href="#" class="fas fa-pen"></a>
                <a href="#" class="fas fa-trash"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
        </div>
        </div>

    </div>

</section>

<!-- doctors section ends -->
