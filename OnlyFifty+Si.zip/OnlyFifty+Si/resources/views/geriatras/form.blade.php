

<section class="book" id="book">

    <br><br><br><br><br><br><br><br>

    <h1 class="heading"> <span>Crear</span> Geriatra </h1>

    <div class="row">

        <div class="image">
            <img src="image/book-img.svg" alt="">
        </div>

        <form action="">

            <input type="number" placeholder="Número de Identificación" class="box">
            <input type="text" placeholder="Nombre Completo" class="box">
            <input type="number" placeholder="Número de Celular" class="box">
            <input type="email" placeholder="Correo Electronico" class="box">
            <input type="file" placeholder="Foto" class="box">
            <input type="password" placeholder="Contraseña" class="box">
            <input type="number" placeholder="Estado" class="box">
            <input type="number" placeholder="Admin" class="box">

            <a href="{{url('paginaInicio')}}" class="btn"> Crear Paciente <span class="fas fa-chevron-right"></span> </a>
        </form>

    </div>

</section>

