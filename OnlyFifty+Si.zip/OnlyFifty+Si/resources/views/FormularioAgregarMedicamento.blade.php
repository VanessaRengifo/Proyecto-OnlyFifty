<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Medicamento</title>

    <link rel="stylesheet" href="styles/IniciarSesion.css">
    <link rel="stylesheet" href="styles/normalize.css">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body >
    <link rel="stylesheet" href="css/style.css">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
@include('barraNavegacionInicio')
<body >
    <!-- booking section starts   -->

<section class="book" id="book">

    <br><br><br><br>
    <h1 class="heading"> <span>Agregar</span> Medicamento </h1>

    <div class="row">

        <div class="image">
            <img src="image/book-img.svg" alt="">
        </div>

        <form action="">

            <input type="text" placeholder="Nombre Completo" class="box">
            <a href="{{url('paginaInicio')}}" class="btn"> Agregar Medicamento <span class="fas fa-chevron-right"></span> </a>
        </form>

    </div>

</section>

<!-- booking section ends -->
</body>
</html>

</body>
</html>

<script src="js/script.js"></script>

</body>
</html>
