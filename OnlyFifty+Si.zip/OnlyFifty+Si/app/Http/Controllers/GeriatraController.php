<?php

namespace App\Http\Controllers;

use App\Models\Geriatra;
use Illuminate\Http\Request;

class GeriatraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $datosGeriatra['geriatras']=Geriatra::paginate(5);
        return view('geriatras.indexGeriatra', $datosGeriatra);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('geriatras.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $datosGeriatra=$request()->except('_token');

        if ($request->hasFile('FOTO')){
            $datosGeriatra['FOTO']=$request ->file('Foto')->store('uploads','public');
        }

        Geriatra::insert($datosGeriatra);

        //return response()->json($datosEmpleado);
        return redirect('geriatra')->with('mensaje','Geriatra agregado con éxito');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Geriatra  $geriatra
     * @return \Illuminate\Http\Response
     */
    public function show(Geriatra $geriatra)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Geriatra  $geriatra
     * @return \Illuminate\Http\Response
     */
    public function edit(Geriatra $geriatra)
    {
        //
        $geriatra=Geriatra::FindOrFail($id);
        return view('geriatra.edit',compact('geriatra') );

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Geriatra  $geriatra
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Geriatra $geriatra)
    {
        //
        $datosGeriatra = request()->except(['_token','_method']);

        if ($request->hasFile('FOTO')){
            $geriatra=Geriatra::FindOrFail($id);

            Storage::delete('public/'.$geriatra->FOTO);

            $datosGeriatra['FOTO']=$request ->file('FOTO')->store('uploads','public');
        }

        Geriatra::where('id','=',$id)->update($datosGeriatra);
        $geriatra=Geriatra::FindOrFail($id);
        return view('geriatras.edit',compact('geriatra') );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Geriatra  $geriatra
     * @return \Illuminate\Http\Response
     */
    public function destroy(Geriatra $geriatra)
    {
        //
    }
}
