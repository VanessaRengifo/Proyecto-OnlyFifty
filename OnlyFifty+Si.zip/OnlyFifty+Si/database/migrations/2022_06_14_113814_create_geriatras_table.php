<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGeriatrasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('geriatras', function (Blueprint $table) {
            $table->id();
            $table->integer('ID_GRIATRA');
            $table->string('NOMBRE_GERIATRA');
            $table->string('NUM_CELULAR');
            $table->string('CORREO_ELECTRONICO');
            $table->string('FOTO');
            $table->string('CLAVE');
            $table->string('ESTADO_GERIATRA');
            $table->string('ADMIN_GERIATRA');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('geriatras');
    }
}
